/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define _GNU_SOURCE

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <time.h>
#include <ctype.h>
#include <time.h>
#include <sys/mman.h>

GtkWidget		*window;
GtkWidget		*fixed1;
GtkWidget		*button1;
GtkWidget		*button2;
GtkWidget		*Tips;
GtkBuilder		*builder; 

//	Callback must be declared before use in callback function below.


void		on_destroy(); 

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv); // init Gtk
	builder = gtk_builder_new_from_file ("part1.glade");
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));
	g_signal_connect(window, "destroy", G_CALLBACK(on_destroy), NULL);
        gtk_builder_connect_signals(builder, NULL);

	fixed1		= GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	button1		= GTK_WIDGET(gtk_builder_get_object(builder, "button1"));
	button2		= GTK_WIDGET(gtk_builder_get_object(builder, "button2"));
	Tips		= GTK_WIDGET(gtk_builder_get_object(builder, "Tips"));

	g_object_unref(builder);
	gtk_window_set_keep_above (GTK_WINDOW(window), TRUE);
	gtk_widget_show(window);
	gtk_main();
	return EXIT_SUCCESS;
	}

void	on_destroy() {
		gtk_main_quit();
		}

void	on_button1_clicked(GtkWidget *b) {
		printf("button1 got clicked\n");
		}

void	on_button2_clicked(GtkWidget *b) {
		printf("button2 got clicked\n");
		}

void	on_Tips_toggled(GtkWidget *b) {
		if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(b))) { // pressed
			gtk_widget_set_has_tooltip (button1, FALSE);
			gtk_widget_set_has_tooltip (button2, FALSE);
			}
		else { // not pressed
			gtk_widget_set_has_tooltip (button1, TRUE);
			gtk_widget_set_has_tooltip (button2, TRUE);
			}
		}

gboolean on_button2_query_tooltip(GtkWidget *b, gint x, gint y, 
		gboolean keyboard, GtkTooltip *tooltip) {
		char tmp[1024] = "The current time is: ";
		time_t t1 = time(NULL);
		strcat(tmp, ctime(&t1));
        	gtk_tooltip_set_text(tooltip, tmp);
        	return TRUE; // show tooltip. return FALSE to no show tooltip.
        	}


