/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define _GNU_SOURCE

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <time.h>
#include <ctype.h>
#include <time.h>
#include <sys/mman.h>

GtkWidget		*window;
GtkWidget		*fixed1;
GtkWidget		*event1;
GtkBuilder		*builder; 

void		on_destroy(); 

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv); // init Gtk

	builder = gtk_builder_new_from_file ("part1.glade");
 
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));

	g_signal_connect(window, "destroy", G_CALLBACK(on_destroy), NULL);

        gtk_builder_connect_signals(builder, NULL);

	fixed1		= GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	event1		= GTK_WIDGET(gtk_builder_get_object(builder, "event1"));

	g_object_unref(builder);

	gtk_window_set_default_size (GTK_WINDOW(window), 500, 700);

	gtk_window_set_keep_above (GTK_WINDOW(window), TRUE);

	gtk_widget_show(window);

	gtk_main();

	return EXIT_SUCCESS;

	}

void	on_destroy() {
		gtk_main_quit();
		}

gboolean	on_event1_motion_notify_event(GtkEventBox *e, GdkEventMotion *event) {

//	These co-ordinates are relative to the upper left of the screen
        int x_event = event -> x_root;	// relative to main window
        int y_event = event -> y_root;	// relative to main window
	printf("\nGtk mouse root coordinates (x,y) %d,%d\n", x_event, y_event);

//	These co-ordinates are relative to the upper left of the event box.
        int x_main = event -> x;	// relative to event window
        int y_main = event -> y;	// relative to event window
	printf("Gtk mouse event box coordinates (x,y) %d,%d\n", x_main, y_main);

//	These coordinates are the event box upper left corner relative to Gtk window
	GdkWindow *Geventbox = gtk_widget_get_window(GTK_WIDGET(e)); // GDK event box window

	int x, y;

	gdk_window_get_position (Geventbox, &x, &y);
	printf("event box position %d %d\n", x, y);

	int hor = gtk_widget_get_allocated_width (GTK_WIDGET(e));
	int ver = gtk_widget_get_allocated_height (GTK_WIDGET(e));
	printf("event box height/width %d %d\n", ver, hor);

	GdkWindow *Gwindow = gtk_widget_get_window(window); // GDK desktop window
	GdkSeat *seat = gdk_display_get_default_seat(gdk_display_get_default ()); // availble devices
	GdkDevice *mouse = gdk_seat_get_pointer(seat); // mouse device
	gdk_window_get_device_position(Gwindow, mouse, &x, &y, NULL); // location of mouse cursor
	printf("Gdk mouse coordinates in window %d,%d\n", x, y);

//	Move the event box & contents. Position event box such that its center is under
//	the mouse cursor.

	gtk_fixed_move (GTK_FIXED(fixed1), GTK_WIDGET(e), x-(hor/2), y-(ver/2));

	return TRUE; // no further processing of this event

//	How to reposition a mouse cursor.
//	In this code, this will usually generate another motion_notify_event
//	(if the left-button is still depressed)

	GdkScreen *screen = gdk_screen_get_default ();
	gdk_device_warp (mouse, screen, x, y);

	}
