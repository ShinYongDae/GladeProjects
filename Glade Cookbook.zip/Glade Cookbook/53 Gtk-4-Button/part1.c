/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019, 2022 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#+ Oct 30, 2022
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk-4.0/gtk/gtk.h>
#include <math.h>
#include <ctype.h>

//-----------------------
//	global objects
//-----------------------

GtkWidget	*window;
GtkWidget	*fixed1;
GtkWidget	*button1;
GtkWidget	*label1;
GtkBuilder	*builder; 
GtkApplication	*app;
void		on_window_destroy(GtkWidget *w);
void		on_window_close_request(GtkWidget *w);

void	on_activate (GtkApplication* app) {

	builder = gtk_builder_new_from_file ("part1.glade");
	
	window = GTK_WIDGET(gtk_builder_get_object (builder, "window"));

	gtk_window_set_application (GTK_WINDOW (window), app);

	g_signal_connect (window, "close-request", G_CALLBACK (on_window_close_request), NULL);

	fixed1 = GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	button1 = GTK_WIDGET(gtk_builder_get_object(builder, "button1"));
	label1 = GTK_WIDGET(gtk_builder_get_object(builder, "label1"));

	gtk_window_set_title (GTK_WINDOW (window), "GTK4 Window");
	gtk_window_set_default_size (GTK_WINDOW (window), 300, 200);
	gtk_widget_show (GTK_WIDGET(window));
	}


int main(int argc, char *argv[]) {

	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);

	g_signal_connect (app, "activate", G_CALLBACK (on_activate), NULL);

	int status = g_application_run (G_APPLICATION (app), argc, argv);

	g_object_unref (app);
	return status;
	}

void	on_button1_clicked (GtkButton *b) {
	gtk_label_set_text (GTK_LABEL(label1), (const gchar* ) "Hello World");
	}

void	on_window_close_request(GtkWidget *w) {
	g_application_quit(G_APPLICATION(app));
	}

void	on_window_destroy(GtkWidget *w) {
	}
