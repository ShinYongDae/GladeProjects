/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <ctype.h>

// Make them global

GtkWidget	*window;
GtkWidget	*fixed1;
GtkWidget	*button1;
GtkWidget	*radio1;
GtkWidget	*radio2;
GtkWidget	*check1;
GtkWidget	*toggle1;
GtkWidget	*scroll1;
GtkBuilder	*builder; 

GtkCssProvider  *cssBtn1; // regular
GtkCssProvider  *cssBtn1a; // clicked

GtkCssProvider  *cssTBtn1; // regular
GtkCssProvider  *cssTBtn1a; // depressed

GtkCssProvider  *cssScroll;

void    css_set(GtkCssProvider *, GtkWidget *);
gboolean timer_handler();

GtkAdjustment	*adjustment2;
int flgBtn1 = 0;

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv); // init Gtk

//---------------------------------------------------------------------
// establish contact with xml code used to adjust widget settings
//---------------------------------------------------------------------
 
	builder = gtk_builder_new_from_file ("part1.glade");
 
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));

	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

        gtk_builder_connect_signals(builder, NULL);

	fixed1 = GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	button1 = GTK_WIDGET(gtk_builder_get_object(builder, "button1"));
	radio1 = GTK_WIDGET(gtk_builder_get_object(builder, "radio1"));
	radio2 = GTK_WIDGET(gtk_builder_get_object(builder, "radio2"));
	check1 = GTK_WIDGET(gtk_builder_get_object(builder, "check1"));
	toggle1 = GTK_WIDGET(gtk_builder_get_object(builder, "toggle1"));
	scroll1 = GTK_WIDGET(gtk_builder_get_object(builder, "scroll1"));

        GdkColor color; 

        if (! gdk_color_parse ("darkblue", &color)) {
                color.red = 0x3333;
                color.green = 0x3333;
                color.blue = 0x9999;
                }

	gtk_widget_modify_bg(window, GTK_STATE_NORMAL, &color);

	cssBtn1 = gtk_css_provider_new();
	cssBtn1a = gtk_css_provider_new();

	cssTBtn1 = gtk_css_provider_new();
	cssTBtn1a = gtk_css_provider_new();

	cssScroll = gtk_css_provider_new();

//	see: https://developer.gnome.org/gtk3/stable/chap-css-overview.html

//-------------- regular button

	gtk_css_provider_load_from_data(cssBtn1,
		"* { background-image: radial-gradient(ellipse at center, yellow 10%, royalblue 100%); }", 
		-1, NULL);
	css_set(cssBtn1, button1);

	gtk_css_provider_load_from_data(cssBtn1a,
		"* { background-image: radial-gradient(ellipse at center, royalblue 10%, royalblue 100%); }", 
		-1, NULL);

//-------------- toggle button

	gtk_css_provider_load_from_data(cssTBtn1,
		"* { background-image: radial-gradient(ellipse at center, red 10%, lightblue 100%); }", 
		-1, NULL);
	css_set(cssTBtn1, toggle1);

	gtk_css_provider_load_from_data(cssTBtn1a,
		"* { background-image: radial-gradient(ellipse at center, red 10%, royalblue 100%); }", 
		-1, NULL);

//-------------- scrollbar

        gtk_css_provider_load_from_data(cssScroll,
                "slider { border: 2px solid blue; padding-left: 0px; padding-right: 0px; "
		"border-radius: 1px; outline: black; background: yellow; border-color: blue;} "
                "trough {background-color: gray;} ", -1, NULL);

	css_set(cssScroll, scroll1);

        g_timeout_add_seconds(1, (GSourceFunc) timer_handler, NULL);

	gtk_widget_show(window);

	gtk_main();

	return EXIT_SUCCESS;
	}

gboolean timer_handler() {

	if (flgBtn1) {
		flgBtn1 = 0;
		css_set(cssBtn1, button1);  // back to normal
		gtk_widget_queue_draw(GTK_WIDGET(button1));
		}

	return TRUE; // returning FALSE ends the timer
	}

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// paint css on a widget
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void    css_set(GtkCssProvider * cssProvider, GtkWidget *g_widget) {

        GtkStyleContext *context;

        context = gtk_widget_get_style_context(g_widget);

        gtk_style_context_add_provider (context,
                GTK_STYLE_PROVIDER(cssProvider),
                GTK_STYLE_PROVIDER_PRIORITY_USER);

        gtk_style_context_save (context);
        }

void	on_button1_clicked (GtkButton *b) {

	flgBtn1 = 1;
	css_set(cssBtn1a, button1);  // clicked state - to be reverted in timer
	gtk_widget_queue_draw(GTK_WIDGET(b));

	printf("I\'ve been clicked!\n");
	}

void	on_radio1_toggled(GtkRadioButton *b) {
	gboolean T = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(b));
	printf("Radio1 toggle state: %d\n", T);
	}

void	on_radio2_toggled(GtkRadioButton *b) {
	gboolean T = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(b));
	printf("Radio2 toggle state: %d\n", T);
	}

void	on_check1_toggled(GtkCheckButton *b) {
	gboolean T = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(b));
	printf("Check1 toggle state: %d\n", T);
	}

void	on_toggle1_toggled(GtkToggleButton *b) {
	gboolean T = gtk_toggle_button_get_active(b);

	if (T) css_set(cssTBtn1a, GTK_WIDGET(b));
	else css_set(cssTBtn1, GTK_WIDGET(b));

	gtk_widget_queue_draw(GTK_WIDGET(b));

	printf("Toggle1 toggle state: %d\n", T);
	}

void    on_scroll1_value_changed(GtkRange *r) {
        gdouble x = gtk_range_get_value (r);
	printf("scroll = %d\n", (int) x );
        }

