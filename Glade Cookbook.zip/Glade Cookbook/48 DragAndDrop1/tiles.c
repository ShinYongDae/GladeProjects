/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Internet Radio Automation & Encoding Toolkit
#+
#+     Copyright (C) 2018, 2019, 2020 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     https://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

// July 19, 2020

#define _GNU_SOURCE

#include <X11/Xlib.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <ctype.h>
#include <time.h>

GtkWidget       *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8, *p9, *p10, *p11, *p12;
GtkWidget	*lbl[12], *randomize;
GtkBuilder	*builder;
GtkWidget	*window;
GtkWidget	*fixed1;

GtkWidget	*target_label;

void		on_window_main_destroy() ;

GdkWindow *gdk_window;

int	drag_source, drag_target;
char	source_text[1024];
char	target_text[1024];
GtkCssProvider  *cssProvider_button;

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// paint css on a widget
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void	css_set(GtkCssProvider * cssProvider, GtkWidget *g_widget) {
	GtkStyleContext *context;
	context = gtk_widget_get_style_context(g_widget);
	gtk_style_context_add_provider (context,
		GTK_STYLE_PROVIDER(cssProvider), 1000);
	}


int main(int argc, char *argv[]) {

	char tmp[1024];

	gtk_init(&argc, &argv);

        builder = gtk_builder_new_from_resource ("/part1/tiles.glade");

        window = GTK_WIDGET(gtk_builder_get_object(builder, "window_main"));

        gtk_builder_connect_signals(builder, NULL);

        g_signal_connect(window, "destroy", G_CALLBACK(on_window_main_destroy), NULL);

	randomize	= GTK_WIDGET(gtk_builder_get_object(builder, "randomize"));
	p1		= GTK_WIDGET(gtk_builder_get_object(builder, "p1"));
	p2		= GTK_WIDGET(gtk_builder_get_object(builder, "p2"));
	p3		= GTK_WIDGET(gtk_builder_get_object(builder, "p3"));
	p4		= GTK_WIDGET(gtk_builder_get_object(builder, "p4"));
	p5		= GTK_WIDGET(gtk_builder_get_object(builder, "p5"));
	p6		= GTK_WIDGET(gtk_builder_get_object(builder, "p6"));
	p7		= GTK_WIDGET(gtk_builder_get_object(builder, "p7"));
	p8		= GTK_WIDGET(gtk_builder_get_object(builder, "p8"));
	p9		= GTK_WIDGET(gtk_builder_get_object(builder, "p9"));
	p10		= GTK_WIDGET(gtk_builder_get_object(builder, "p10"));
	p11		= GTK_WIDGET(gtk_builder_get_object(builder, "p11"));
	p12		= GTK_WIDGET(gtk_builder_get_object(builder, "p12"));
	lbl[0]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl1"));
	lbl[1]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl2"));
	lbl[2]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl3"));
	lbl[3]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl4"));
	lbl[4]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl5"));
	lbl[5]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl6"));
	lbl[6]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl7"));
	lbl[7]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl8"));
	lbl[8]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl9"));
	lbl[9]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl10"));
	lbl[10]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl11"));
	lbl[11]		= GTK_WIDGET(gtk_builder_get_object(builder, "lbl12"));

	fixed1		= GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));

	char codes[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	srand ((unsigned int) time(NULL));

	for (int i = 0; i < 12; i++) {
		sprintf(tmp, "%c", codes[rand() % 26]);
        	gtk_label_set_text(GTK_LABEL(lbl[i]), tmp);
		}

        cssProvider_button = gtk_css_provider_new();
        gtk_css_provider_load_from_resource(cssProvider_button, "/part1/css/albumButton.css");

        css_set(cssProvider_button, p1 );
        css_set(cssProvider_button, p2 );
        css_set(cssProvider_button, p3 );
        css_set(cssProvider_button, p4 );
        css_set(cssProvider_button, p5 );
        css_set(cssProvider_button, p6 );
        css_set(cssProvider_button, p7 );
        css_set(cssProvider_button, p8 );
        css_set(cssProvider_button, p9 );
        css_set(cssProvider_button, p10 );
        css_set(cssProvider_button, p11 );
        css_set(cssProvider_button, p12 );

	gtk_widget_show(window);

	GdkColor color; 
	color.red = 0x5555; color.green = 0x5555; color.blue = 0x6666;

	gtk_widget_modify_bg(window, GTK_STATE_NORMAL, &color);

	gdk_window = gtk_widget_get_window(GTK_WIDGET(window));

	gtk_widget_show_all(window); 

	GtkTargetEntry targs[1] = {"dummy", GTK_TARGET_SAME_APP, 1};

//	GtkTargetEntry structure:
//		gchar *target;
//		guint  flags;
//		guint  info;

//	GDK_BUTTON1_MASK means first (left) mouse button
//	GTK_DESTINATION_DEFAULT_ALL turns on all options 

//	macro code -------------------------

//	set up drag permissions

#define P_BUTTON_DRAG_SETUP(NBR) \
	gtk_drag_source_set(p## NBR, GDK_BUTTON1_MASK, targs, 1, GDK_ACTION_COPY);  \
	gtk_drag_dest_set(p## NBR , GTK_DEST_DEFAULT_DROP | GTK_DEST_DEFAULT_HIGHLIGHT | GTK_DEST_DEFAULT_MOTION,  \
		targs, 1, GDK_ACTION_COPY);


        P_BUTTON_DRAG_SETUP(1) P_BUTTON_DRAG_SETUP(2) P_BUTTON_DRAG_SETUP(3) P_BUTTON_DRAG_SETUP(4) 
	P_BUTTON_DRAG_SETUP(5) P_BUTTON_DRAG_SETUP(6) P_BUTTON_DRAG_SETUP(7) P_BUTTON_DRAG_SETUP(8) 
	P_BUTTON_DRAG_SETUP(9) P_BUTTON_DRAG_SETUP(10) P_BUTTON_DRAG_SETUP(11) P_BUTTON_DRAG_SETUP(12)

	gtk_main(); // here we go!

	}

// ----------------------------------------------------------------

void on_window_main_destroy() {
	gtk_main_quit();
	}

//	macro code -------------------------

//	button left click

#define P_BUTTON_CLICKED(NBR) \
        void on_p## NBR ##_clicked(GtkWidget *b) { \
        printf("click %d\n", NBR); }

	P_BUTTON_CLICKED(1) P_BUTTON_CLICKED(2)  P_BUTTON_CLICKED(3)  P_BUTTON_CLICKED(4)  
	P_BUTTON_CLICKED(5) P_BUTTON_CLICKED(6) P_BUTTON_CLICKED(7) P_BUTTON_CLICKED(8)
	P_BUTTON_CLICKED(9)  P_BUTTON_CLICKED(10) P_BUTTON_CLICKED(11) P_BUTTON_CLICKED(12)

//	macro code - several routines ------

//	drag functions
//	Note: always use /* ... */ style comments in macros

#define P_BUTTON_DRAG(NBR)  \
        void on_p## NBR ##_drag_begin (GtkWidget *w, GdkDragContext *dc) {  \
			/* drag has begun */  \
			printf("drag begin %d\n", NBR);  \
                        drag_source =  NBR;  \
                        }  \
			\
        void on_p## NBR ##_drag_drop (GtkWidget *w, GdkDragContext *dc) {  \
			/* drag has ended (button released) */  \
			/* button will be NBR of target button */  \
			printf("drop %d\n", NBR); \
                        drag_target = NBR; /* buttton number 1-12 */  \
			target_label = lbl[ NBR - 1 ]; /* pointer */  \
                        } \
			\
        void on_p## NBR ##_drag_data_get (GtkWidget *w, GdkDragContext *dc) {  \
			/* drag has ended (button released) */  \
			/* NBR will be NBR of source button */  \
			printf("get %d\n", NBR);  \
                        } \
			\
        void on_p## NBR ##_drag_end (GtkWidget *w, GdkDragContext *dc) {  \
		/* last function called */  \
		/* extract label texts */  \
		strcpy(target_text, gtk_label_get_text(GTK_LABEL(target_label)) );  \
		strcpy(source_text, gtk_label_get_text(GTK_LABEL(lbl[ NBR - 1 ])) ); /* current label */  \
                printf("move \"%s\" from tile %d to tile %d\n", source_text, drag_source, drag_target);  \
		/* exchange label contents */  \
        	gtk_label_set_text(GTK_LABEL(target_label), source_text);  \
        	gtk_label_set_text(GTK_LABEL(lbl[ NBR - 1 ]), target_text);  \
                drag_source = drag_target = -1; }

	P_BUTTON_DRAG(1) P_BUTTON_DRAG(2)  P_BUTTON_DRAG(3)  P_BUTTON_DRAG(4)
	P_BUTTON_DRAG(5) P_BUTTON_DRAG(6)  P_BUTTON_DRAG(7)  P_BUTTON_DRAG(8)
	P_BUTTON_DRAG(9) P_BUTTON_DRAG(10) P_BUTTON_DRAG(11) P_BUTTON_DRAG(12)

//	macro code -------------------------

#define P_BUTTON_PRESS(NBR)  \
        gboolean on_p## NBR ##_button_press_event  \
                (GtkButton *btn, GdkEventButton *event, gpointer user_data) {  \
		printf("button press %d\n", NBR);  \
                if (event->state == GDK_CONTROL_MASK) printf("ctrl key pressed\n");  \
		/* return TRUE: no futher processing of this signal */  \
		/* return FALSE: continue processing this signal */  \
                if (event->button == 1 ) return FALSE; /* left click - processing will be handled elsewhere */  \
                printf("right click\n");  \
                return TRUE;  /* no further processing */  \
                }

	P_BUTTON_PRESS(1) P_BUTTON_PRESS(2)  P_BUTTON_PRESS(3)  P_BUTTON_PRESS(4)
	P_BUTTON_PRESS(5) P_BUTTON_PRESS(6)  P_BUTTON_PRESS(7)  P_BUTTON_PRESS(8)
	P_BUTTON_PRESS(9) P_BUTTON_PRESS(10) P_BUTTON_PRESS(11) P_BUTTON_PRESS(12)

void	on_randomize_clicked(GtkWidget *b) {

//	randomize the tile contents

	char codes[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char tmp[32];

	for (int i = 0; i< 12; i++) {
		sprintf(tmp, "%c", codes[rand()%26]);
        	gtk_label_set_text(GTK_LABEL(lbl[i]), tmp);
		}
	}
