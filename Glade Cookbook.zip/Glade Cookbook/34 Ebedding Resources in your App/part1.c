/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define _GNU_SOURCE

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <time.h>
#include <ctype.h>
#include <time.h>
#include <sys/mman.h>

GtkWidget		*window;
GtkWidget		*fixed1;
GtkWidget		*launch1;
GtkWidget		*close1;
GtkWidget		*move1;
GtkWidget		*deco1;
GtkWidget		*deco2;
GtkWidget		*above1;
GtkWidget		*image1;
GtkBuilder		*builder; 

//	Callback must be declared before use in callback function below.


void		on_destroy(); 

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv); // init Gtk

//	builder = gtk_builder_new_from_file ("part1.glade");
	builder = gtk_builder_new_from_resource ("/part1/part1.glade");
 
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));

	g_signal_connect(window, "destroy", G_CALLBACK(on_destroy), NULL);

        gtk_builder_connect_signals(builder, NULL);

	fixed1		= GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	launch1		= GTK_WIDGET(gtk_builder_get_object(builder, "launch1"));
	close1		= GTK_WIDGET(gtk_builder_get_object(builder, "close1"));
	move1		= GTK_WIDGET(gtk_builder_get_object(builder, "move1"));
	deco1		= GTK_WIDGET(gtk_builder_get_object(builder, "deco1"));
	deco2		= GTK_WIDGET(gtk_builder_get_object(builder, "deco2"));
	above1		= GTK_WIDGET(gtk_builder_get_object(builder, "above1"));
	image1		= GTK_WIDGET(gtk_builder_get_object(builder, "image1"));

	g_object_unref(builder);

//	gtk_window_set_default_size (GTK_WINDOW(window), 700, 700);

	gtk_window_set_keep_above (GTK_WINDOW(window), TRUE);

	gtk_widget_show(window);

	gtk_main();

	return EXIT_SUCCESS;

	}

void	on_destroy() {
		gtk_main_quit();
		}

void	on_launch1_clicked(GtkButton *b) {
	system("gpicview panAm.jpg &");
	}

void	on_close1_clicked(GtkButton *b) {
	system ("wmctrl -c \"panAm.jpg\""); // killall could be used also
	}

void	on_move1_clicked(GtkButton *b) {
	char cmd[512];
	sprintf(cmd, "wmctrl -r \"panAm.jpg\" -e 0,%d,%d,%d,%d",
		500, 500, 300, 400); // hor, ver, width, height
	system(cmd);
	}

void	on_deco1_clicked(GtkButton *b) {
	char idnbr[32], cmd[128];
	FILE *p1;
        p1=popen("wmctrl -l | grep -i \"panAm\" ","r");
        fscanf(p1,"%s", idnbr);
        fclose (p1);

	sprintf(cmd,"xprop -id %s -f _MOTIF_WM_HINTS 32c \
		-set _MOTIF_WM_HINTS \"0x2, 0x0, 0x0, 0x0, 0x0\" ", idnbr);
	system(cmd);

//	Alternative method if you know the FULL name of the window
//	strcpy(cmd, "xprop -name \"panAm.jpg\" "
//		"-f _MOTIF_WM_HINTS 32c -set _MOTIF_WM_HINTS \"0x2, 0x0, 0x0, 0x0, 0x0\"");
//	system(cmd);
	}

void	on_deco2_clicked(GtkButton *b) {
	char idnbr[32], cmd[128];
	FILE *p1;
        p1=popen("wmctrl -l | grep -i \"panAm\" ","r");
        fscanf(p1,"%s", idnbr);
        fclose (p1);

	sprintf(cmd,"xprop -id %s -f _MOTIF_WM_HINTS 32c \
		-set _MOTIF_WM_HINTS \"0x0, 0x0, 0x0, 0x0, 0x0\" ", idnbr);
	system(cmd);
	}

void	on_above1_clicked(GtkButton *b) {

//	This is semi-effective. Sometimes it does not work.
//	See other "-b" options in: man wmctrl

	system("wmctrl -r \"panAm.jpg\" -b add,above");
	}

//-------------------------------------------------------
//      locate detached application
//-------------------------------------------------------

void    on_findApp_clicked (GtkButton *b) {

        int desktop,hor,ver,wid,hgt;
        unsigned int hexId;
        char cmd[1024];
        FILE *f1;

        f1=popen("wmctrl -lG | grep \"panAm\"", "r");

        strcpy(cmd,"");

        if (fgets(cmd,1024,f1) != NULL) { // where is it?

                sscanf(cmd,"%x %d %d %d %d %d", 
			&hexId, &desktop, &hor, &ver, &wid, &hgt);

                printf("hexId=%x desktop=%d hor=%d ver=%d wide=%d high=%d\n",
                        hexId, desktop, hor, ver, wid, hgt);
                }
	else printf("Not found\n");

        fclose(f1);
        }

