/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <ctype.h>

// Make them global

GtkWidget	*window;
GtkWidget	*fixed1;
GtkWidget	*scroll1;
GtkWidget	*b1;
GtkBuilder	*builder; 

GtkAdjustment	*adjustment2;

void    css_set(GtkCssProvider *, GtkWidget *);

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv); // init Gtk

//---------------------------------------------------------------------
// establish contact with xml code used to adjust widget settings
//---------------------------------------------------------------------
 
	builder = gtk_builder_new_from_file ("part1.glade");
 
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));

        GtkCssProvider  *cssProvider1;
        cssProvider1  = gtk_css_provider_new();

        gtk_css_provider_load_from_path(cssProvider1, "/home/okane/Desktop/Glade Cookbook/part40/gtk.css", NULL);
        css_set(cssProvider1, window);

	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

        gtk_builder_connect_signals(builder, NULL);

	fixed1 = GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	scroll1 = GTK_WIDGET(gtk_builder_get_object(builder, "scroll1"));
	b1 = GTK_WIDGET(gtk_builder_get_object(builder, "b1"));

	adjustment2 = GTK_ADJUSTMENT(gtk_builder_get_object(builder, "adjustment2"));

	/*******************
	struct GtkAdjustment {
                    gdouble lower,
                    gdouble upper,
                    gdouble step_increment,
                    gdouble page_increment,
                    gdouble page_size};
	****************************/

	/* how to alter the range of the scroll bar */
	/* gtk_range_set_range (GTK_RANGE(scroll1), 0, 100); */

//        GtkCssProvider  *cssProvider1;
//        cssProvider1  = gtk_css_provider_new();
//
//        gtk_css_provider_load_from_path(cssProvider1, "/home/okane/Desktop/Glade Cookbook/part40/gtk.css", NULL);

//        css_set(cssProvider1, scroll1);
//        css_set(cssProvider1, b1);
//        css_set(cssProvider1, window);

gtk_style_context_add_provider_for_screen(gdk_screen_get_default(),
                               GTK_STYLE_PROVIDER(cssProvider1),
                               GTK_STYLE_PROVIDER_PRIORITY_USER);

GError *error = NULL;
GtkIconTheme *icon_theme;

// icon_theme = gtk_icon_theme_get_default ();

icon_theme = gtk_icon_theme_new();

char **path;
gint ele;

gtk_icon_theme_get_search_path (icon_theme, &path, &ele);
printf("number of paths: %d\n", ele);
for (int i=0; i< ele; i++) printf("path %d %s\n", i, path[i]);

// icon_theme = gtk_icon_theme_get_default ();
// printf("aaa %s\n", gtk_icon_theme_get_example_icon_name (icon_theme));

//gtk_icon_theme_rescan_if_needed (icon_theme);
gtk_icon_theme_set_custom_theme (icon_theme, "GNOME");
gtk_icon_theme_set_screen (icon_theme, gdk_screen_get_default());
//gtk_icon_theme_rescan_if_needed (icon_theme);
printf("aaa %s\n", gtk_icon_theme_get_example_icon_name (icon_theme));

	gtk_widget_show(window);

	gtk_main();

	return EXIT_SUCCESS;
	}

void    on_scroll1_value_changed(GtkRange *r) {
        gdouble x = gtk_range_get_value (r);
	printf("scroll = %d\n", (int) x );
        }

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// paint css on a widget
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void    css_set(GtkCssProvider * cssProvider, GtkWidget *g_widget) {

        GtkStyleContext *context = gtk_widget_get_style_context(g_widget);

        gtk_style_context_add_provider (context,
                GTK_STYLE_PROVIDER(cssProvider),
                GTK_STYLE_PROVIDER_PRIORITY_USER);
        }

