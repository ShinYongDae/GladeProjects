/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define _GNU_SOURCE

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <time.h>
#include <ctype.h>
#include <time.h>
#include <sys/mman.h>

GtkWidget		*window;
GtkWidget		*fixed1;
GtkWidget		*WinSize;
GtkWidget		*MoveWindow;
GtkWidget		*ChangeTitle;
GtkWidget		*DecorationsOff;
GtkWidget		*DecorationsOn;
GtkWidget		*FullScreenOn;
GtkWidget		*FullScreenOff;
GtkBuilder		*builder; 

void		on_destroy(); 

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv); // init Gtk

	builder = gtk_builder_new_from_file ("part1.glade");
 
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));

	g_signal_connect(window, "destroy", G_CALLBACK(on_destroy), NULL);

        gtk_builder_connect_signals(builder, NULL);

	fixed1		= GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	WinSize		= GTK_WIDGET(gtk_builder_get_object(builder, "WinSize"));
	MoveWindow	= GTK_WIDGET(gtk_builder_get_object(builder, "MoveWindow"));
	ChangeTitle	= GTK_WIDGET(gtk_builder_get_object(builder, "ChangeTitle"));
	DecorationsOn	= GTK_WIDGET(gtk_builder_get_object(builder, "DecorationsOn"));
	DecorationsOff	= GTK_WIDGET(gtk_builder_get_object(builder, "DecorationsOff"));
	FullScreenOn	= GTK_WIDGET(gtk_builder_get_object(builder, "FullScreenOn"));
	FullScreenOff	= GTK_WIDGET(gtk_builder_get_object(builder, "FullScreenOff"));

	g_object_unref(builder);

	gtk_window_set_default_size (GTK_WINDOW(window), 700, 700);

	gtk_window_set_keep_above (GTK_WINDOW(window), TRUE);

	gtk_widget_show(window);

	gtk_main();

	return EXIT_SUCCESS;

	}

void	on_WinSize_clicked(GtkButton *b) {
	gtk_window_resize (GTK_WINDOW(window), 400, 400);
	}

void	on_MoveWindow_clicked(GtkButton *b) {
	gtk_window_move (GTK_WINDOW(window), 400, 400);
	}	

void	on_ChangeTitle_clicked(GtkButton *b) {
	char tmp[512] = "Time now is: ";
	time_t t = time(0);
	strcpy(&tmp[13], ctime(&t));
	tmp[strlen(tmp)-1] = 0;
	gtk_window_set_title (GTK_WINDOW(window), tmp);
	}

void	on_DecorationsOff_clicked(GtkButton *b) {
	gtk_window_set_decorated (GTK_WINDOW(window), FALSE);
	}

void	on_DecorationsOn_clicked(GtkButton *b) {
	gtk_window_set_decorated (GTK_WINDOW(window), TRUE);
	}

void	on_FullScreenOn_clicked(GtkButton *b) {
	gtk_window_fullscreen(GTK_WINDOW(window));
	}

void	on_FullScreenOff_clicked(GtkButton *b) {
	gtk_window_unfullscreen(GTK_WINDOW(window));
	}

void	on_destroy() {
		gtk_main_quit();
		}
