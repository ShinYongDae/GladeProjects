/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Glade / Gtk Programming
#+
#+     Copyright (C) 2019 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     http://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <time.h>
#include <ctype.h>
#include <sys/mman.h>

// Make them global

GtkWidget	*window;
GtkWidget	*fixed1;
GtkWidget	*grid1; 
GtkWidget	*label[1000];
GtkWidget	*button[1000];
GtkWidget	*view1;
GtkBuilder	*builder; 

void		on_destroy(); 
void		on_row(GtkButton *);

char	tmp[1024]; // general use
int	row;

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv); // init Gtk

//---------------------------------------------------------------------
// establish contact with xml code used to adjust widget settings
//---------------------------------------------------------------------
 
	builder = gtk_builder_new_from_file ("part1.glade");
 
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));

	g_signal_connect(window, "destroy", G_CALLBACK(on_destroy), NULL);

        gtk_builder_connect_signals(builder, NULL);

	fixed1 = GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
	view1 = GTK_WIDGET(gtk_builder_get_object(builder, "view1"));
	grid1 = GTK_WIDGET(gtk_builder_get_object(builder, "grid1"));

	FILE *f1 = fopen("functions.txt", "r");

	if (f1 == NULL ) {
		printf("File finctions.txt not found\n");
		return EXIT_FAILURE;
		}

	row = 0;
	while (1) {
		if (fgets(tmp, 1024, f1) == NULL) {
			fclose(f1);
			break;
			}
		tmp[strlen(tmp)-1] = 0; // remove newline byte
		gtk_grid_insert_row (GTK_GRID(grid1), row);

//		The following code will populate the grid with non-clicable labels

//		label[row] = gtk_label_new (tmp);
//		gtk_label_set_justify (GTK_LABEL(label[row]), GTK_JUSTIFY_LEFT);
//		gtk_label_set_xalign (GTK_LABEL(label[row]), 0.0);
//		gtk_grid_attach (GTK_GRID(grid1), label[row], 1, row, 1, 1);

//		The following code will populate the grid with clickable buttons.

//		A button can be freed by the function 'gtk_container_remove ()'

		button[row] = gtk_button_new_with_label (tmp);
		gtk_button_set_alignment (GTK_BUTTON(button[row]), 0.0, 0.5); // hor left, ver center
		gtk_grid_attach (GTK_GRID(grid1), button[row], 1, row, 1, 1);
		g_signal_connect(button[row], "clicked", G_CALLBACK(on_row), NULL);
		row ++;
		}

//-----------------------------------

	gtk_widget_show_all(window);

	gtk_main();

	return EXIT_SUCCESS;
	}

//......................................................................................


void	on_row(GtkButton *b) {
	printf("You selected: %s\n", gtk_button_get_label (b));
	}

void	on_destroy() { 
		gtk_main_quit();
		}
