/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+
#+     Internet Radio Automation & Encoding Toolkit
#+
#+     Copyright (C) 2018, 2019, 2020 by Kevin C. O'Kane
#+
#+     Kevin C. O'Kane
#+     kc.okane@gmail.com
#+     https://www.cs.uni.edu/~okane
#+     https://threadsafebooks.com/
#+
#+ This program is free software; you can redistribute it and/or modify
#+ it under the terms of the GNU General Public License as published by
#+ the Free Software Foundation; either version 2 of the License, or
#+ (at your option) any later version.
#+
#+ This program is distributed in the hope that it will be useful,
#+ but WITHOUT ANY WARRANTY; without even the implied warranty of
#+ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#+ GNU General Public License for more details.
#+
#+ You should have received a copy of the GNU General Public License
#+ along with this program; if not, write to the Free Software
#+ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#+
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

//----------------------------------------------------
//	GtkWebKit References
//
//	GtkWebKit libraries:
//
//		apt-get  install libwebkit2gtk-4.0-dev
//
//	Documentation
//
//		https://webkitgtk.org/
//
//		https://webkitgtk.org/reference/webkit2gtk/stable/
//			WebKitNavigationAction.html
//
//		https://webkitgtk.org/reference/webkit2gtk/stable/
//			WebKitNavigationPolicyDecision.html#WebKitNavigationType
//----------------------------------------------------

// July 12, 2021
// webkit.c

#define _GNU_SOURCE

#include <X11/Xlib.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <ctype.h>
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <webkit2/webkit2.h>

GtkBuilder	*builder;
GtkWidget	*window;
GtkWidget	*fixed1;
GtkWidget	*webx, *weby;
GtkWidget	*uri;
GtkWidget	*go;
GtkWidget	*close_web;
GtkWidget	*text_link;

WebKitSettings *settings1;

char web_url[4096];

void on_window_destroy() ;

int main(int argc, char *argv[]) {

	gtk_init(&argc, &argv);

	webkit_web_view_get_type();
	webkit_settings_get_type();

//-------------------------------------------------------------------------
//	error fix see: https://bugs.webkit.org/show_bug.cgi?id=175937
//-------------------------------------------------------------------------

        builder = gtk_builder_new_from_resource ("/part1/webkit.glade");

        window = GTK_WIDGET(gtk_builder_get_object(builder, "window_main"));

        gtk_builder_connect_signals(builder, NULL);

        fixed1 = GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
        webx = GTK_WIDGET(gtk_builder_get_object(builder, "webx"));
        weby = GTK_WIDGET(gtk_builder_get_object(builder, "weby"));
        uri = GTK_WIDGET(gtk_builder_get_object(builder, "uri"));
        go = GTK_WIDGET(gtk_builder_get_object(builder, "go"));
        close_web = GTK_WIDGET(gtk_builder_get_object(builder, "close_web"));
        text_link = GTK_WIDGET(gtk_builder_get_object(builder, "text_link"));
        settings1 = WEBKIT_SETTINGS(gtk_builder_get_object(builder, "settings1"));

	gtk_widget_hide(weby); // webkitview window
	gtk_widget_hide(close_web); // button

	gtk_window_resize(window, 400, 400); // shrink to minimum

//	load initial web page

//	strcpy(web_url, "https://www.cs.uni.edu/~okane/");

	strcpy(web_url, "file:///home/okane/Desktop/WebKit/menu.html");

        webkit_web_view_load_uri(WEBKIT_WEB_VIEW(webx), web_url);

	GdkColor color; // default background color - optional
		color.red   = 0x5555;
		color.green = 0x5555;
		color.blue  = 0x6666;
		gtk_widget_modify_bg(window, GTK_STATE_NORMAL, &color);

//	example altering web settings:
//	webkit_settings_set_minimum_font_size (WEBKIT_SETTINGS(settings1), 34);

//	webkit_web_view_set_zoom_level (webx, 1.5); // a spin button to do this?

	gtk_main(); // here we go!

	}

void on_window_destroy() {
	gtk_main_quit();
	}


void	on_uri_changed(GtkEntry *e) {
	strncpy(web_url, gtk_entry_get_text(e), 4096);
	}


void    on_go_clicked(GtkWidget *w) {
        if (strlen(web_url) == 0) return;
        webkit_web_view_load_uri(WEBKIT_WEB_VIEW(webx), web_url);
        }


gboolean on_webx_load_failed (WebKitWebView  *web_view, WebKitLoadEvent load_event, 
		char *failing_uri, GError *error) {

	printf("GError: (%d) %s\n", error-> code, error-> message);

	if (error->code == 204) return TRUE; // plug in handled load

	strcpy(web_url, "file:///home/okane/Desktop/WebKit/menu.html");

        webkit_web_view_load_uri(WEBKIT_WEB_VIEW(webx), web_url); // reload default page

        return TRUE; // no further processing of this signal
        }


GtkWidget* on_webx_create (WebKitWebView *web_view, WebKitNavigationAction *navigation_action) {

	WebKitNavigationType type = webkit_navigation_action_get_navigation_type (navigation_action);

	int mouse;

	printf("Mouse button: %d\n",
		mouse = webkit_navigation_action_get_mouse_button (navigation_action));

	if (type == WEBKIT_NAVIGATION_TYPE_LINK_CLICKED) 
		printf("The navigation was triggered by clicking a link.\n");

	else if (type == WEBKIT_NAVIGATION_TYPE_FORM_SUBMITTED) 
		printf("The navigation was triggered by submitting a form.\n");

	else if (type == WEBKIT_NAVIGATION_TYPE_BACK_FORWARD) 
		printf("The navigation was triggered by navigating forward or backward.\n");

	else if (type == WEBKIT_NAVIGATION_TYPE_RELOAD) 
		printf("The navigation was triggered by reloading.\n");

	else if (type == WEBKIT_NAVIGATION_TYPE_FORM_RESUBMITTED) 
		printf("The navigation was triggered by resubmitting a form.\n");

	else if (type == WEBKIT_NAVIGATION_TYPE_OTHER) 
		printf("The navigation was triggered by some other action.\n");

	WebKitURIRequest *req = webkit_navigation_action_get_request (navigation_action);

	gchar *uri =  webkit_uri_request_get_uri (req);

	printf("Request URI = %s\n", uri);

	if (type == WEBKIT_NAVIGATION_TYPE_OTHER && mouse == 0)  {
		return weby; // view in which to open page
		}

	return web_view;
	}


void	on_webx_mouse_target_changed(WebKitWebView *web_view, WebKitHitTestResult *hit_test_result, 
		guint modifiers) {

//	get pointer to text of link under mouse

	gchar *link = webkit_hit_test_result_get_link_uri (hit_test_result);

	if (link != NULL) gtk_label_set_text(text_link, link);
	else gtk_label_set_text(text_link, "");

	}

GtkWidget* on_weby_create (WebKitWebView *web_view, WebKitNavigationAction *navigation_action) {
	return web_view; // i.e., weby
	}


void	on_weby_ready_to_show(WebKitWebView *web_view) {

//	view fully painted - time to show

	gtk_widget_show(weby); // view window
	gtk_widget_show(close_web); // button

	}


void	on_close_web_clicked(GtkWidget *w) {

//	hide stuff and shink window

	gtk_widget_hide(weby);
	gtk_widget_hide(close_web);
	gtk_window_resize(window, 400, 400);

	}
